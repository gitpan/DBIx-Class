package # Hide from PAUSE
  DBIx::Class::SQLAHacks;

use base qw/DBIx::Class::SQLMaker/;

1;
