package DBICNSTest::RtBug41083::ResultSet_A::A;
use strict;
use warnings;
use base 'DBICNSTest::RtBug41083::ResultSet';

sub fooBar { 1; }
1;
