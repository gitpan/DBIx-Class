package DBICNSTest::RSet::A;
use base qw/DBIx::Class::ResultSet/;
1;
