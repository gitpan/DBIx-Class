package DBICNSTest::ResultSet::A;
use base qw/DBIx::Class::ResultSet/;
1;
