package DBICNSTest::Bogus::Bigos;

1;
