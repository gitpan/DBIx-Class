package # Hide from PAUSE
  DBIx::Class::SQLAHacks::MySQL;

use base qw( DBIx::Class::SQLMaker::MySQL );

1;
